const express = require('express');
const router = express.Router();
const pokemonController = require('../controllers/pokemonController');

router.get('/', pokemonController.getAllPokemon);
router.get('/:id', pokemonController.getPokemonById);  // 根据 pokemonId 查询
router.get('/type/:type', pokemonController.getPokemonByType);
router.get('/name/:name', pokemonController.getPokemonByName);  // 按英语名称查询

module.exports = router;
