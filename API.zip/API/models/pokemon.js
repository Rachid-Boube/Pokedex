const mongoose = require('mongoose');

const PokemonSchema = new mongoose.Schema({
    pokemonId: { type: Number, required: true, unique: true },
    name: {
        english: { type: String, required: true },
        japanese: { type: String },
        chinese: { type: String },
        french: { type: String }
    },
    type: [{ type: String, required: true }],
    base: {
        HP: { type: Number },
        Attack: { type: Number },
        Defense: { type: Number },
        Sp_Attack: { type: Number },
        Sp_Defense: { type: Number },
        Speed: { type: Number }
    },
    description: { type: String }
});

module.exports = mongoose.model('Pokemon', PokemonSchema);
