const express = require('express');
const connectDB = require('./config/db');
const pokemonRoutes = require('./routes/pokemonRoutes');  // 更新后的路径
require('dotenv').config();
const cors = require('cors');

const app = express();
connectDB();

app.use(express.json());
app.use(cors());

app.use('/api/pokemon', pokemonRoutes);  // 路由使用 pokemonRoutes

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
