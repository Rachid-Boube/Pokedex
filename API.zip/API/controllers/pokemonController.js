const Pokemon = require('../models/pokemon');

// 获取所有 Pokémon
exports.getAllPokemon = async (req, res) => {
    try {
        const pokemons = await Pokemon.find();
        res.json(pokemons);
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

// 按 pokemonId 获取 Pokémon
exports.getPokemonById = async (req, res) => {
    try {
        const pokemon = await Pokemon.findOne({ pokemonId: req.params.id });  // 修改为 pokemonId
        if (!pokemon) return res.status(404).json({ msg: 'Pokémon not found' });
        res.json(pokemon);
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

// 按类型获取 Pokémon
exports.getPokemonByType = async (req, res) => {
    try {
        const pokemons = await Pokemon.find({ type: req.params.type });
        res.json(pokemons);
    } catch (err) {
        res.status(500).send('Server Error');
    }
};

// 按名称获取 Pokémon（按英语名称）
exports.getPokemonByName = async (req, res) => {
    try {
        const pokemons = await Pokemon.find({
            'name.english': new RegExp(req.params.name, 'i')  // 按英语名称查询
        });
        res.json(pokemons);
    } catch (err) {
        res.status(500).send('Server Error');
    }
};
